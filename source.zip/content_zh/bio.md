我是**梁佳钰**，自 2024 年起就读于**哈尔滨工业大学**，现为**大数据管理与应用**专业本科生。

联系邮箱：[jiayu_liang@stu.hit.edu.cn](mailto:jiayu_liang@stu.hit.edu.cn)
