# 梁佳钰的个人主页

基于 PRISM，保留原项目 MIT 许可证。主页仅包含姓名、学校、本科身份、专业、入学年份和学校邮箱；论文、经历、教学、奖项、服务、研究兴趣及社交链接留空。

## 修改内容

- 英文身份与链接：`content/config.toml`
- 中文身份与链接：`content_zh/config.toml`
- 英文介绍：`content/bio.md`
- 中文介绍：`content_zh/bio.md`
- 论文：`content/publications.bib` 和 `content_zh/publications.bib`
- 简历：`content/cv.md` 和 `content_zh/cv.md`
- 其他栏目：对应语言目录内的 `teaching.toml`、`awards.toml`、`services.toml`、`news.toml`

如需照片，将图片放在 `public/`，再填写 `author.avatar`。当前照片为 `public/profile.jpg`，网页显示区域为 256 × 256 像素的圆角正方形，使用 CSS 裁切，原照片保留。

修改内容后需要重新构建、发布，网站才会更新。不要重新运行 `personalize.py`，否则会把后续补充内容重置为空。

## OpenReview 注册

使用邮箱 `jiayu_liang@stu.hit.edu.cn`，将部署后公开网址填写在 Homepage 字段。英文姓名使用 `Jiayu Liang`，如注册时采用其他拼写，请同步修改主页。该网页用于展示身份信息，不替代 OpenReview 邮箱验证或账户审核。

