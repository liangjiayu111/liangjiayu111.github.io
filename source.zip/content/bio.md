I am **Jiayu Liang (梁佳钰)**, an undergraduate student at **Harbin Institute of Technology**, studying **Big Data Management and Application** since 2024.

Email: [jiayu_liang@stu.hit.edu.cn](mailto:jiayu_liang@stu.hit.edu.cn)
